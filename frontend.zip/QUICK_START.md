# 🎯 Quick Start Guide - Microplastic Detection

## ✅ System Status

- **Backend API**: Running on `http://localhost:8000` ✓
- **Frontend Server**: Running on `http://localhost:3000` ✓
- **ML Model**: YOLOv8 best.pt loaded ✓
- **Webcam**: Ready for live detection ✓

## 🚀 Getting Started

### Step 1: Open Live Detection Page
Go to your browser and open:
```
http://localhost:3000/live-detection.html
```

### Step 2: Click "Start Detection"
- Click the big blue "Start Detection" button
- Browser will ask for **camera permission**
- Click **"Allow"** to grant camera access

### Step 3: See Live Detection
- Webcam feed will appear on screen
- Your ML model will analyze frames every 500ms
- See:
  - ✓ Bounding boxes around detected microplastics
  - ✓ Confidence scores
  - ✓ Real-time statistics

### Step 4: Stop Detection
- Click "Stop Detection" button to end session

---

## 📋 Other Pages

| Page | URL | Purpose |
|------|-----|---------|
| **Live Detection** | `http://localhost:3000/live-detection.html` | Real-time webcam analysis |
| **Image Detection** | `http://localhost:3000/detection.html` | Upload images to analyze |
| **Dashboard** | `http://localhost:3000/dashboard.html` | View statistics |
| **Map** | `http://localhost:3000/map.html` | Location tracking |
| **Reports** | `http://localhost:3000/reports.html` | View reports |
| **Diagnostic** | `http://localhost:3000/test-live-detection.html` | Troubleshooting tool |

---

## 🔧 Troubleshooting

### Issue: "Start Detection" button not responding

**Solution 1: Check Browser Console**
1. Press `F12` to open Developer Tools
2. Go to **Console** tab
3. Click "Start Detection"
4. Look for error messages (red text)
5. Share the error message

**Solution 2: Allow Camera Permission**
1. Check if browser asked for camera permission
2. Look for permission prompt at top of browser
3. Click "Allow"
4. Reload page and try again

**Solution 3: Check if Camera is Connected**
- Make sure webcam is plugged in
- No other app is using the camera
- Try: `http://localhost:3000/test-live-detection.html` and click "Test Camera Support"

**Solution 4: Restart Servers**
```bash
# Kill existing processes
pkill -f "uvicorn"
pkill -f "http.server 3000"

# Restart backend
cd /home/atchayasree/Downloads/microplastixk
.venv/bin/python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 &

# Restart frontend
python3 -m http.server 3000 &
```

### Issue: "Not Found" error
- ❌ Wrong: `http://localhost:8000/live-detection.html`
- ✅ Correct: `http://localhost:3000/live-detection.html`

**Remember**: Port 3000 = Frontend, Port 8000 = Backend

---

## 🎥 What's Happening

When you click "Start Detection":

1. **Camera Access Request**
   - Browser asks for permission
   - You click "Allow"

2. **Video Stream Started**
   - Webcam feed appears
   - 1280x720 resolution

3. **Detection Loop Begins**
   - Every 500ms: captures frame
   - Sends to backend API
   - Your ML model processes it

4. **Results Displayed**
   - Bounding boxes drawn
   - Statistics updated
   - FPS counter shown

---

## 📊 System Architecture

```
User Browser (Port 3000)
    ↓
    ├── Captures frame from webcam
    ├── Converts to JPEG
    └── Sends to Backend API
         ↓
    Backend API (Port 8000)
         ├── Receives frame
         ├── Loads your ML model (best.pt)
         ├── Runs YOLOv8 inference
         └── Returns detections
         ↓
    Browser displays results
         ├── Draws bounding boxes
         ├── Updates statistics
         └── Continues loop
```

---

## ✅ Model Verified

Your ML model has been tested and confirmed working:
- ✓ Model file: `backend/model/best.pt` (21.48 MB)
- ✓ Framework: YOLOv8
- ✓ Detection test: 1 object detected with 0.93 confidence
- ✓ Status classification: "Low Contamination"

**Your model is ready!**

---

## 💡 Tips

1. **Good lighting** = Better detection
2. **Steady hand** = Clearer bounding boxes
3. **1280x720 resolution** = Optimal for your setup
4. **500ms intervals** = Good balance between speed and accuracy

---

## 🆘 Still Having Issues?

1. Visit: `http://localhost:3000/test-live-detection.html`
2. Click "Run All Tests"
3. Check the results
4. Report any red errors

Or check the console for errors:
- Press `F12`
- Go to **Console** tab
- Look for messages starting with `❌` or in red

**Good luck! 🚀**
