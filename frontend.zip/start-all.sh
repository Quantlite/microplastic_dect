#!/bin/bash

# Microplastic Detection - Start All Services

echo "🚀 Starting Microplastic Detection System..."
echo "================================================"

# Check if running from correct directory
if [ ! -d ".venv" ]; then
    echo "❌ Error: .venv directory not found"
    echo "Please run this script from: /home/atchayasree/Downloads/microplastixk"
    exit 1
fi

# Kill any existing processes
echo "🛑 Stopping existing processes..."
pkill -f "uvicorn backend.main" 2>/dev/null
pkill -f "http.server 3000" 2>/dev/null
sleep 2

# Start backend
echo ""
echo "🔵 Starting Backend API (Port 8000)..."
./.venv/bin/python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 &
BACKEND_PID=$!
sleep 3

# Start frontend
echo "🟢 Starting Frontend Server (Port 3000)..."
python3 -m http.server 3000 &
FRONTEND_PID=$!
sleep 2

# Check if services are running
echo ""
echo "✅ System Started!"
echo "================================================"
echo ""
echo "📍 Open in browser:"
echo "   http://localhost:3000/live-detection.html"
echo ""
echo "🔧 Other URLs:"
echo "   • Detection (upload): http://localhost:3000/detection.html"
echo "   • Dashboard: http://localhost:3000/dashboard.html"
echo "   • Diagnostic: http://localhost:3000/test-live-detection.html"
echo ""
echo "🎯 Backend API: http://localhost:8000/health"
echo ""
echo "🛑 To stop all services:"
echo "   pkill -f 'uvicorn backend.main'"
echo "   pkill -f 'http.server 3000'"
echo ""
echo "================================================"

# Keep script running
wait
