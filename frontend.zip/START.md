# Microplastic Detection Platform - Startup Guide

## Prerequisites
- Python 3.8+
- pip
- Node.js (optional, for local server)

## Step 1: Install Backend Dependencies

```bash
cd backend
pip install -r requirements.txt
```

Or manually install:
```bash
pip install fastapi uvicorn python-multipart opencv-python numpy yolov8
```

## Step 2: Start the Backend Server

```bash
cd backend
python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The backend will start at `http://localhost:8000`

## Step 3: Start the Frontend

### Option 1: Using Python's built-in server
```bash
# From the root directory
python -m http.server 5500
```

Then open: `http://localhost:5500`

### Option 2: Using Node.js (if installed)
```bash
npx http-server -p 5500
```

Then open: `http://localhost:5500`

### Option 3: Open directly in browser
Simply open `index.html` in your browser (limited functionality)

## Connection Details

- **Frontend**: `http://localhost:5500`
- **Backend API**: `http://localhost:8000`
- **Detection Endpoint**: `http://localhost:8000/detect`

## Features

✅ Upload images for detection
✅ Real-time live detection via camera
✅ Interactive map with markers
✅ Dashboard with statistics
✅ Report generation
✅ Admin login

## Troubleshooting

### Backend not connecting
- Make sure backend is running on port 8000
- Check CORS is enabled (already configured)
- Open browser console (F12) to see error messages

### Image detection fails
- Ensure the model file `best.pt` exists in `backend/model/`
- Check backend console for error messages
- Verify image format is JPEG/PNG

### Live detection not working
- Check camera permissions
- Ensure browser has camera access
- Try refreshing the page

## API Endpoints

- **POST /detect** - Analyze image for microplastics
  - Input: multipart/form-data with `file` field
  - Output: JSON with detections, count, and status
