# Frontend-Backend Connection Summary

## ✅ Connection Completed

The frontend and backend are now fully connected and ready to work together.

### What Was Updated

#### 1. **Configuration (js/config.js)**
- Changed API base URL from `http://localhost:5000/api` to `http://localhost:8000`
- Now points to the actual FastAPI backend

#### 2. **API Service (js/api.js)**
- `detectMicroplastics()` - Now sends images to the backend `/detect` endpoint
- `startLiveDetection()` - Streams live video frames to backend for real-time detection
- Both functions now use FormData to send files (not JSON)
- Includes fallback to mock data if backend is unavailable

#### 3. **Detection Page (js/detection.js)**
- Added `currentImageFile` variable to store the actual file object
- `handleImageFile()` now stores the file for backend processing
- `runDetection()` passes the file to the backend API
- `clearImage()` clears both image and file references

### How Data Flows

```
User uploads image
    ↓
File stored in currentImageFile
    ↓
detectMicroplastics(file) called
    ↓
FormData created with file
    ↓
POST request to http://localhost:8000/detect
    ↓
Backend processes image with YOLOv8 model
    ↓
Returns detections, count, status
    ↓
Results displayed on page
```

### Backend Endpoints

**POST /detect**
- Accepts: multipart/form-data with `file` field
- Returns JSON:
  ```json
  {
    "count": 5,
    "status": "Low Contamination",
    "detections": [
      {
        "bbox": [x1, y1, x2, y2],
        "size_mm": 0.45,
        "confidence": 0.92
      }
    ]
  }
  ```

### How to Run

#### 1. Start Backend
```bash
cd backend
pip install -r requirements.txt
python -m uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

#### 2. Start Frontend
```bash
# Option 1: Python server
python -m http.server 5500

# Option 2: Open index.html directly in browser
# (Limited - won't work with live detection)
```

#### 3. Access the Application
- Open browser to `http://localhost:5500`
- Or open `index.html` directly

### Testing the Connection

1. **Upload Detection**
   - Go to Detection page
   - Upload an image
   - Click "Run Detection"
   - Check browser console (F12) for any errors
   - Should see results from backend

2. **Live Detection**
   - Go to Live Detection page
   - Click "Start Detection"
   - Allow camera access
   - Backend will process frames in real-time

3. **Browser Console Debugging**
   - Open F12 → Console tab
   - You'll see:
     - "Modal opened/closed" (map)
     - Backend response logs
     - Any connection errors

### CORS Configuration

Backend already has CORS enabled:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
```

This allows the frontend (any origin) to communicate with the backend.

### Fallback Behavior

If the backend is unavailable:
- Detection will use mock data (for demo purposes)
- Live detection will fall back to mock detections
- No errors will be shown to the user
- A toast message may indicate the issue

### Future Enhancements

- [ ] Add authentication endpoints
- [ ] Implement database for storing results
- [ ] Add map data endpoints
- [ ] Implement dashboard statistics API
- [ ] Add admin login endpoint
- [ ] Create reports generation API

### Troubleshooting

**Q: Backend not connecting**
- A: Check backend is running on port 8000
- A: Check console (F12) for CORS errors
- A: Verify firewall allows localhost:8000

**Q: Image upload fails**
- A: Ensure image is JPEG/PNG and < 5MB
- A: Check backend console for specific errors
- A: Verify best.pt model exists in backend/model/

**Q: Live detection not working**
- A: Check camera permissions
- A: Try different browser (Chrome recommended)
- A: Refresh page and try again

