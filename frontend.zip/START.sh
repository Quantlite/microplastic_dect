#!/bin/bash

# 🔬 Microplastic Detection System - Startup Script
# This script starts both the backend API and frontend server

echo "╔════════════════════════════════════════════════════════════╗"
echo "║     🔬 MICROPLASTIC DETECTION - LIVE OBJECT DETECTION      ║"
echo "║                   Starting System...                        ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Get the directory where this script is located
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to check if port is in use
check_port() {
    netstat -tuln 2>/dev/null | grep ":$1 " > /dev/null 2>&1
    return $?
}

# Kill existing processes on ports 8000 and 3000
echo "🧹 Cleaning up existing processes..."
pkill -f "uvicorn.*backend.main" 2>/dev/null || true
pkill -f "http.server 3000" 2>/dev/null || true
sleep 2

# Check if ports are free
if check_port 8000; then
    echo -e "${RED}❌ Port 8000 is still in use. Please kill the process manually.${NC}"
    exit 1
fi

if check_port 3000; then
    echo -e "${RED}❌ Port 3000 is still in use. Please kill the process manually.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Ports are free${NC}"
echo ""

# Start Backend Server
echo "🚀 Starting Backend Server (Port 8000)..."
.venv/bin/python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload > /tmp/backend.log 2>&1 &
BACKEND_PID=$!
echo -e "${GREEN}✅ Backend PID: $BACKEND_PID${NC}"
sleep 3

# Check if backend started successfully
if curl -s http://localhost:8000/health > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Backend is responding${NC}"
    HEALTH=$(curl -s http://localhost:8000/health | grep -o '"model_loaded":[^,}]*')
    echo -e "${GREEN}   $HEALTH${NC}"
else
    echo -e "${RED}❌ Backend failed to start${NC}"
    cat /tmp/backend.log
    exit 1
fi

echo ""

# Start Frontend Server
echo "🚀 Starting Frontend Server (Port 3000)..."
python3 -m http.server 3000 > /tmp/frontend.log 2>&1 &
FRONTEND_PID=$!
echo -e "${GREEN}✅ Frontend PID: $FRONTEND_PID${NC}"
sleep 2

# Check if frontend started successfully
if curl -s http://localhost:3000/ > /dev/null 2>&1; then
    echo -e "${GREEN}✅ Frontend is responding${NC}"
else
    echo -e "${RED}❌ Frontend failed to start${NC}"
    cat /tmp/frontend.log
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║                   ✅ SYSTEM STARTED                        ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo -e "${GREEN}📍 BACKEND:${NC}   http://localhost:8000"
echo -e "${GREEN}   Health:   http://localhost:8000/health${NC}"
echo ""
echo -e "${GREEN}📍 FRONTEND:${NC}  http://localhost:3000"
echo -e "${GREEN}   Live Detection: http://localhost:3000/live-detection.html${NC}"
echo ""
echo -e "${YELLOW}🎬 NEXT STEPS:${NC}"
echo "   1. Open your browser to: http://localhost:3000/live-detection.html"
echo "   2. Click 'Start Detection' button"
echo "   3. Allow camera access when prompted"
echo "   4. Watch real-time microplastic detection!"
echo ""
echo -e "${YELLOW}📊 FEATURES:${NC}"
echo "   ✓ Live webcam detection"
echo "   ✓ Real-time bounding boxes"
echo "   ✓ Confidence scores"
echo "   ✓ FPS counter"
echo "   ✓ Detection statistics"
echo ""
echo -e "${YELLOW}⚡ KEYBOARD SHORTCUTS:${NC}"
echo "   Ctrl+C  - Stop backend server"
echo "   Press Ctrl+C in another terminal to stop frontend"
echo ""
echo -e "${YELLOW}🔧 VIEW LOGS:${NC}"
echo "   Backend:  tail -f /tmp/backend.log"
echo "   Frontend: tail -f /tmp/frontend.log"
echo ""
echo "Press Ctrl+C to stop the backend server when done."
echo ""

# Wait for backend process
wait $BACKEND_PID
