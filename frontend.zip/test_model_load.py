
from ultralytics import YOLO
import sys

try:
    print("Loading model...")
    model = YOLO("backend/model/best.pt")
    print("Model loaded successfully")
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
