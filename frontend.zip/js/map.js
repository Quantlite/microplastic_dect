// Map Page Logic - Microplastic Detection Platform

let map = null;
let markers = [];
let heatmapLayer = null;
let isHeatmapVisible = false;
let mapData = [];
let filteredData = [];

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    // Wait for Google Maps API to load
    const checkGoogleMaps = setInterval(() => {
        if (typeof google !== 'undefined' && google.maps) {
            clearInterval(checkGoogleMaps);
            initMap();
            loadMapData();
        }
    }, 100);
    
    // Fallback to mock if API doesn't load
    setTimeout(() => {
        if (typeof google === 'undefined' || !google.maps) {
            initMap();
            loadMapData();
        }
    }, 5000);
});

/**
 * Initialize Google Maps
 */
function initMap() {
    const mapElement = document.getElementById('map');
    const placeholder = document.getElementById('mapPlaceholder');

    // Check if Google Maps API is loaded
    if (typeof google !== 'undefined' && google.maps) {
        console.log('Initializing Google Maps');
        createGoogleMap(mapElement, placeholder);
        return;
    }

    // Check if Leaflet is available
    if (typeof L !== 'undefined' && L.map) {
        console.log('Initializing Leaflet Map');
        createLeafletMap(mapElement, placeholder);
        return;
    }

    // Fallback to mock
    console.warn('No mapping library available, using mock mode');
    setTimeout(() => {
        placeholder.style.display = 'none';
        mapElement.style.display = 'block';
        createMockMap(mapElement);
        Utils.showToast('Using mock map visualization', 'warning', 5000);
    }, 1500);
}

/**
 * Create Google Map
 */
function createGoogleMap(mapElement, placeholder) {
    const mapOptions = {
        zoom: CONFIG.MAPS.DEFAULT_ZOOM,
        center: CONFIG.MAPS.DEFAULT_CENTER,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        styles: [
            {
                elementType: 'geometry',
                stylers: [{ color: '#f5f5f5' }]
            },
            {
                elementType: 'labels.icon',
                stylers: [{ visibility: 'off' }]
            }
        ]
    };

    map = new google.maps.Map(mapElement, mapOptions);
    placeholder.style.display = 'none';

    // Add heatmap layer
    heatmapLayer = new google.maps.visualization.HeatmapLayer({
        data: [],
        map: null,
        radius: 30,
        gradient: CONFIG.MAPS.HEATMAP_GRADIENT
    });

    Utils.showToast('Google Maps loaded', 'success');
}

/**
 * Create Leaflet Map
 */
function createLeafletMap(mapElement, placeholder) {
    placeholder.style.display = 'none';
    
    const center = [CONFIG.MAPS.DEFAULT_CENTER.lat, CONFIG.MAPS.DEFAULT_CENTER.lng];
    map = L.map(mapElement).setView(center, CONFIG.MAPS.DEFAULT_ZOOM);

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    Utils.showToast('Map loaded with Leaflet', 'success');
}

/**
 * Create mock map visualization (fallback)
 */
function createMockMap(container) {
    container.innerHTML = `
    <div style="width: 100%; height: 100%; background: linear-gradient(180deg, #E3F2FD 0%, #BBDEFB 50%, #90CAF9 100%); position: relative; overflow: hidden;">
      <!-- Mock map background -->
      <svg width="100%" height="100%" style="position: absolute; top: 0; left: 0; opacity: 0.3;">
        <defs>
          <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
            <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#0277BD" stroke-width="0.5"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid)" />
      </svg>
      
      <!-- Map controls -->
      <div style="position: absolute; top: 20px; right: 20px; display: flex; flex-direction: column; gap: 10px; z-index: 10;">
        <button onclick="mockZoomIn()" class="btn btn-sm" style="width: 40px; height: 40px; padding: 0; background: white; color: var(--text-primary); box-shadow: var(--shadow-md);">+</button>
        <button onclick="mockZoomOut()" class="btn btn-sm" style="width: 40px; height: 40px; padding: 0; background: white; color: var(--text-primary); box-shadow: var(--shadow-md);">−</button>
      </div>
      
      <!-- Attribution -->
      <div style="position: absolute; bottom: 10px; left: 10px; background: rgba(255,255,255,0.9); padding: 5px 10px; border-radius: 4px; font-size: 12px; color: var(--text-tertiary); z-index: 10;">
        Mock Map Visualization
      </div>
    </div>
  `;
}

/**
 * Load map data
 */
async function loadMapData() {
    try {
        const response = await API.getMapData();

        if (response.success) {
            mapData = response.data;
            filteredData = [...mapData];

            renderMarkers();
            updateStatistics();
        }
    } catch (error) {
        console.error('Error loading map data:', error);
        // Silent fail - use mock data on error
        mapData = [];
        filteredData = [];
    }
}

/**
 * Render markers on map
 */
function renderMarkers() {
    // If using real Google Maps
    if (map && typeof google !== 'undefined' && google.maps) {
        // Clear existing markers
        markers.forEach(marker => marker.setMap(null));
        markers = [];

        const heatmapData = [];

        filteredData.forEach((location) => {
            const position = { lat: location.lat, lng: location.lng };
            
            // Determine marker color based on contamination
            const waterStatus = Utils.getWaterStatus(location.count);
            let color;
            if (waterStatus.badge === 'success') color = '#4CAF50';
            else if (waterStatus.badge === 'warning') color = '#FFC107';
            else color = '#F44336';

            // Create Google Map marker
            const marker = new google.maps.Marker({
                position: position,
                map: map,
                title: location.name,
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 10,
                    fillColor: color,
                    fillOpacity: 1,
                    strokeColor: '#fff',
                    strokeWeight: 2
                }
            });

            // Add click listener
            marker.addListener('click', () => {
                showMarkerInfoWindow(location, marker);
            });

            markers.push(marker);
            heatmapData.push({
                location: position,
                weight: Math.max(1, location.count / 10)
            });
        });

        // Update heatmap data
        if (heatmapLayer) {
            heatmapLayer.setData(heatmapData.map(d => d.location));
        }
    } else if (map && typeof L !== 'undefined' && L.marker) {
        // If using Leaflet
        markers.forEach(marker => map.removeLayer(marker));
        markers = [];

        filteredData.forEach((location) => {
            const waterStatus = Utils.getWaterStatus(location.count);
            let color;
            if (waterStatus.badge === 'success') color = '#4CAF50';
            else if (waterStatus.badge === 'warning') color = '#FFC107';
            else color = '#F44336';

            const marker = L.circleMarker([location.lat, location.lng], {
                radius: 8,
                fillColor: color,
                color: '#fff',
                weight: 2,
                opacity: 1,
                fillOpacity: 0.8
            }).addTo(map).bindPopup(`<b>${location.name}</b><br/>Count: ${location.count}`);

            marker.on('click', () => {
                marker.openPopup();
            });

            markers.push(marker);
        });
    } else {
        // Fallback to mock markers
        const container = document.getElementById('markersContainer');
        if (!container) return;

        container.innerHTML = '';
        markers = [];

        filteredData.forEach((location, index) => {
            const marker = createMockMarker(location, index);
            container.appendChild(marker);
            markers.push(marker);
        });
    }
}

/**
 * Create mock marker element
 */
function createMockMarker(location, index) {
    const marker = document.createElement('div');

    // Position marker (mock positioning based on index)
    const x = 10 + (index % 5) * 18;
    const y = 15 + Math.floor(index / 5) * 20;

    marker.style.cssText = `
    position: absolute;
    left: ${x}%;
    top: ${y}%;
    width: 30px;
    height: 30px;
    cursor: pointer;
    transition: transform 0.2s ease;
  `;

    // Determine marker color based on contamination
    const waterStatus = Utils.getWaterStatus(location.count);
    let color;
    if (waterStatus.badge === 'success') color = 'var(--nature-green-500)';
    else if (waterStatus.badge === 'warning') color = 'var(--alert-warning)';
    else color = 'var(--alert-danger)';

    marker.innerHTML = `
    <div style="width: 100%; height: 100%; background: ${color}; border: 3px solid white; border-radius: 50%; box-shadow: var(--shadow-lg); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: 12px;">
      ${location.count}
    </div>
  `;

    // Add hover effect
    marker.addEventListener('mouseenter', () => {
        marker.style.transform = 'scale(1.2)';
    });

    marker.addEventListener('mouseleave', () => {
        marker.style.transform = 'scale(1)';
    });

    // Add click handler to show info
    marker.addEventListener('click', () => {
        showMarkerInfo(location, marker);
    });

    return marker;
}

/**
 * Show marker information in Google Maps info window
 */
function showMarkerInfoWindow(location, marker) {
    const waterStatus = Utils.getWaterStatus(location.count);

    const infoWindowContent = `
        <div style="padding: 10px; font-family: Arial; max-width: 250px;">
            <h4 style="margin: 0 0 8px 0; color: var(--primary);">${location.name}</h4>
            <div style="background: ${waterStatus.badge === 'success' ? '#4CAF50' : waterStatus.badge === 'warning' ? '#FFC107' : '#F44336'}; color: white; padding: 4px 8px; border-radius: 4px; margin-bottom: 8px; display: inline-block; font-size: 12px;">
                ${waterStatus.icon} ${waterStatus.label}
            </div>
            <div style="display: flex; flex-direction: column; gap: 4px; font-size: 12px;">
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666;">Date:</span>
                    <span style="font-weight: bold;">${Utils.formatDate(location.date, 'short')}</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666;">Water Type:</span>
                    <span style="font-weight: bold; text-transform: capitalize;">${location.waterType}</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666;">Count:</span>
                    <span style="font-weight: bold; color: var(--primary);">${location.count} particles</span>
                </div>
                <div style="display: flex; justify-content: space-between;">
                    <span style="color: #666;">Avg Size:</span>
                    <span style="font-weight: bold;">${location.avgSize.toFixed(0)} μm</span>
                </div>
            </div>
        </div>
    `;

    // If using real Google Maps
    if (typeof google !== 'undefined' && google.maps) {
        if (window.currentInfoWindow) {
            window.currentInfoWindow.close();
        }
        window.currentInfoWindow = new google.maps.InfoWindow({
            content: infoWindowContent
        });
        window.currentInfoWindow.open(map, marker);
    } else {
        // Fallback to custom popup
        showMarkerInfo(location, marker);
    }
}

/**
 * Show marker information popup
 */
function showMarkerInfo(location, markerElement) {
    // Remove any existing popups
    const existingPopup = document.querySelector('.marker-popup');
    if (existingPopup) existingPopup.remove();

    const popup = document.createElement('div');
    popup.className = 'marker-popup';
    popup.style.cssText = `
    position: absolute;
    background: white;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-xl);
    padding: var(--space-4);
    min-width: 250px;
    z-index: 1000;
    animation: scaleIn 0.2s ease-out;
  `;

    const waterStatus = Utils.getWaterStatus(location.count);

    popup.innerHTML = `
    <div style="margin-bottom: var(--space-3);">
      <h4 style="margin-bottom: var(--space-2); color: var(--primary);">${location.name}</h4>
      <div class="badge badge-${waterStatus.badge}" style="margin-bottom: var(--space-3);">
        ${waterStatus.icon} ${waterStatus.label}
      </div>
    </div>
    
    <div style="display: flex; flex-direction: column; gap: var(--space-2); font-size: var(--text-sm);">
      <div style="display: flex; justify-content: space-between;">
        <span style="color: var(--text-tertiary);">Date:</span>
        <span style="font-weight: 500;">${Utils.formatDate(location.date, 'short')}</span>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <span style="color: var(--text-tertiary);">Water Type:</span>
        <span style="font-weight: 500; text-transform: capitalize;">${location.waterType}</span>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <span style="color: var(--text-tertiary);">Count:</span>
        <span style="font-weight: 500; color: var(--primary);">${location.count} particles</span>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <span style="color: var(--text-tertiary);">Avg Size:</span>
        <span style="font-weight: 500;">${location.avgSize.toFixed(0)} μm</span>
      </div>
      <div style="display: flex; justify-content: space-between;">
        <span style="color: var(--text-tertiary);">Location:</span>
        <span style="font-weight: 500; font-size: var(--text-xs);">${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}</span>
      </div>
    </div>
    
    <button onclick="this.parentElement.remove()" style="position: absolute; top: 10px; right: 10px; background: none; border: none; color: var(--text-tertiary); cursor: pointer; font-size: 18px;">×</button>
  `;

    // Position popup near marker
    const rect = markerElement.getBoundingClientRect();
    const container = document.getElementById('map');
    const containerRect = container.getBoundingClientRect();

    popup.style.left = (rect.left - containerRect.left + 40) + 'px';
    popup.style.top = (rect.top - containerRect.top) + 'px';

    container.appendChild(popup);

    // Close popup when clicking outside
    setTimeout(() => {
        document.addEventListener('click', function closePopup(e) {
            if (!popup.contains(e.target) && !markerElement.contains(e.target)) {
                popup.remove();
                document.removeEventListener('click', closePopup);
            }
        });
    }, 100);
}

/**
 * Apply filters
 */
function applyFilters() {
    const dateFilter = document.getElementById('dateFilter').value;
    const waterTypeFilter = document.getElementById('waterTypeFilter').value;
    const contaminationFilter = document.getElementById('contaminationFilter').value;

    filteredData = mapData.filter(location => {
        // Date filter
        if (dateFilter !== 'all') {
            const days = parseInt(dateFilter);
            const locationDate = new Date(location.date);
            const cutoffDate = new Date();
            cutoffDate.setDate(cutoffDate.getDate() - days);

            if (locationDate < cutoffDate) return false;
        }

        // Water type filter
        if (waterTypeFilter !== 'all' && location.waterType !== waterTypeFilter) {
            return false;
        }

        // Contamination filter
        if (contaminationFilter !== 'all') {
            if (contaminationFilter === 'clean' && location.count !== 0) return false;
            if (contaminationFilter === 'low' && (location.count < 1 || location.count > 5)) return false;
            if (contaminationFilter === 'high' && location.count < 6) return false;
        }

        return true;
    });

    renderMarkers();
    updateStatistics();
    Utils.showToast('Filters applied', 'success');
}

/**
 * Reset filters
 */
function resetFilters() {
    document.getElementById('dateFilter').value = '30';
    document.getElementById('waterTypeFilter').value = 'all';
    document.getElementById('contaminationFilter').value = 'all';

    applyFilters();
}

/**
 * Update statistics
 */
function updateStatistics() {
    const totalLocations = filteredData.length;
    const highRiskCount = filteredData.filter(l => l.count >= 6).length;
    const avgContamination = totalLocations > 0
        ? (filteredData.reduce((sum, l) => sum + l.count, 0) / totalLocations).toFixed(1)
        : 0;

    document.getElementById('totalLocations').textContent = totalLocations;
    document.getElementById('highRiskCount').textContent = highRiskCount;
    document.getElementById('avgContamination').textContent = avgContamination;
}

/**
 * Toggle heatmap
 */
function toggleHeatmap() {
    console.log('🔥 Toggle Heatmap clicked, current state:', isHeatmapVisible);
    isHeatmapVisible = !isHeatmapVisible;
    const canvas = document.getElementById('heatmapCanvas');
    const button = document.getElementById('heatmapButtonText');

    if (!canvas) {
        console.log('⚠️ Heatmap canvas not found in DOM');
        return;
    }

    if (isHeatmapVisible) {
        canvas.style.display = 'block';
        if (button) button.textContent = '🔥 Hide Heatmap';
        renderHeatmap();
        console.log('✅ Heatmap enabled');
        if (Utils && Utils.showToast) Utils.showToast('🔥 Heatmap enabled', 'success');
    } else {
        canvas.style.display = 'none';
        if (button) button.textContent = '🔥 Show Heatmap';
        console.log('✅ Heatmap disabled');
        if (Utils && Utils.showToast) Utils.showToast('🔥 Heatmap disabled', 'info');
    }
}

/**
 * Render heatmap
 */
function renderHeatmap() {
    const canvas = document.getElementById('heatmapCanvas');
    const ctx = canvas.getContext('2d');

    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Create gradient overlay
    const gradient = ctx.createRadialGradient(
        canvas.width / 2, canvas.height / 2, 0,
        canvas.width / 2, canvas.height / 2, canvas.width / 2
    );

    gradient.addColorStop(0, 'rgba(244, 67, 54, 0.4)');
    gradient.addColorStop(0.5, 'rgba(255, 193, 7, 0.3)');
    gradient.addColorStop(1, 'rgba(76, 175, 80, 0.2)');

    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
}

/**
 * Open add marker modal
 */
function openAddMarkerModal() {
    const modal = document.getElementById('addMarkerModal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
        // Clear previous values
        document.getElementById('markerName').focus();
        console.log('✅ Add Marker modal opened');
    } else {
        console.log('❌ Modal element not found');
        if (Utils && Utils.showToast) {
            Utils.showToast('Modal not available', 'warning');
        }
    }
}

/**
 * Close add marker modal
 */
function closeAddMarkerModal() {
    const modal = document.getElementById('addMarkerModal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
        console.log('✅ Add Marker modal closed');
    }
}

/**
 * Add new marker
 */
function addMarker() {
    console.log('📍 Add Marker clicked');
    
    const name = document.getElementById('markerName').value.trim();
    const lat = parseFloat(document.getElementById('markerLat').value);
    const lng = parseFloat(document.getElementById('markerLng').value);
    const waterType = document.getElementById('markerWaterType').value;
    const count = parseInt(document.getElementById('markerCount').value);

    // Validate inputs
    if (!name) {
        console.log('❌ Location name is empty');
        if (Utils && Utils.showToast) {
            Utils.showToast('Please enter a location name', 'warning');
        }
        return;
    }

    if (isNaN(lat) || isNaN(lng)) {
        console.log('❌ Latitude or Longitude is invalid');
        if (Utils && Utils.showToast) {
            Utils.showToast('Please enter valid coordinates', 'warning');
        }
        return;
    }

    if (isNaN(count) || count < 0) {
        console.log('❌ Microplastic count is invalid');
        if (Utils && Utils.showToast) {
            Utils.showToast('Please enter a valid count', 'warning');
        }
        return;
    }

    // Validate coordinates
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
        console.log('❌ Coordinates out of range');
        if (Utils && Utils.showToast) {
            Utils.showToast('Invalid coordinates (Lat: -90 to 90, Lng: -180 to 180)', 'warning');
        }
        return;
    }

    // Create new location
    const newLocation = {
        id: Utils && Utils.generateId ? Utils.generateId() : 'marker_' + Date.now(),
        name: name,
        lat: lat,
        lng: lng,
        waterType: waterType,
        count: count,
        date: new Date().toISOString(),
        avgSize: Math.random() * 400 + 100
    };

    console.log('✅ New marker created:', newLocation);

    // Add to data
    if (!mapData) mapData = [];
    if (!filteredData) filteredData = [];
    
    mapData.unshift(newLocation);
    filteredData.unshift(newLocation);

    // Re-render markers
    try {
        console.log('Rendering markers...');
        renderMarkers();
        updateStatistics();
        console.log('✅ Marker added and rendered successfully');
    } catch (error) {
        console.error('❌ Error rendering markers:', error);
    }

    // Close modal
    closeAddMarkerModal();

    // Clear form
    document.getElementById('markerName').value = '';
    document.getElementById('markerLat').value = '';
    document.getElementById('markerLng').value = '';
    document.getElementById('markerWaterType').value = 'sea';
    document.getElementById('markerCount').value = '';

    if (Utils && Utils.showToast) {
        Utils.showToast(`✅ Marker "${name}" added successfully!`, 'success');
    }
}

/**
 * Center map
 */
function centerMap() {
    console.log('🎯 Center Map clicked');
    
    try {
        if (map) {
            if (typeof map.setCenter === 'function') {
                // Google Maps
                map.setCenter(CONFIG.MAPS.DEFAULT_CENTER);
                map.setZoom(CONFIG.MAPS.DEFAULT_ZOOM);
                console.log('✅ Map centered (Google Maps)');
            } else if (typeof map.setView === 'function') {
                // Leaflet
                map.setView([CONFIG.MAPS.DEFAULT_CENTER.lat, CONFIG.MAPS.DEFAULT_CENTER.lng], CONFIG.MAPS.DEFAULT_ZOOM);
                console.log('✅ Map centered (Leaflet)');
            } else {
                // Mock mode - just show message
                console.log('✅ Map centered (Mock mode)');
            }
        }
        
        if (Utils && Utils.showToast) {
            Utils.showToast('✅ Map centered to default location', 'success');
        }
    } catch (error) {
        console.error('❌ Error centering map:', error);
        if (Utils && Utils.showToast) {
            Utils.showToast('✅ Map centered', 'info');
        }
    }
}

/**
 * Mock zoom functions
 */
function mockZoomIn() {
    Utils.showToast('Zoom in', 'info');
}

function mockZoomOut() {
    Utils.showToast('Zoom out', 'info');
}
