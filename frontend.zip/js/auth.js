// Authentication Module - Microplastic Detection Platform

const Auth = {
    /**
     * Check if user is authenticated
     */
    isAuthenticated() {
        const token = Utils.storage.get(CONFIG.STORAGE.AUTH_TOKEN);
        const user = Utils.storage.get(CONFIG.STORAGE.USER_DATA);
        return !!(token && user);
    },

    /**
     * Get current user
     */
    getCurrentUser() {
        return Utils.storage.get(CONFIG.STORAGE.USER_DATA);
    },

    /**
     * Get auth token
     */
    getToken() {
        return Utils.storage.get(CONFIG.STORAGE.AUTH_TOKEN);
    },

    /**
     * Login user
     */
    async login(email, password) {
        try {
            const response = await API.login({ email, password });

            if (response.success) {
                return {
                    success: true,
                    user: response.data.user
                };
            } else {
                return {
                    success: false,
                    error: response.error || 'Login failed'
                };
            }
        } catch (error) {
            console.error('Login error:', error);
            return {
                success: false,
                error: 'An error occurred during login'
            };
        }
    },

    /**
     * Logout user
     */
    async logout() {
        try {
            await API.logout();
            window.location.href = 'login.html';
        } catch (error) {
            console.error('Logout error:', error);
        }
    },

    /**
     * Require authentication (redirect if not authenticated)
     */
    requireAuth(redirectUrl = 'login.html') {
        if (!this.isAuthenticated()) {
            window.location.href = redirectUrl;
            return false;
        }
        return true;
    },

    /**
     * Check user role
     */
    hasRole(role) {
        const user = this.getCurrentUser();
        return user && user.role === role;
    },

    /**
     * Initialize auth state on page load
     */
    init() {
        const user = this.getCurrentUser();

        // Update UI if user is logged in
        if (user) {
            this.updateAuthUI(user);
        }
    },

    /**
     * Update UI based on auth state
     */
    updateAuthUI(user) {
        // Update navbar with user info
        const authButton = document.querySelector('.auth-button');
        if (authButton && user) {
            authButton.innerHTML = `
        <div class="flex items-center gap-2">
          <span>${user.name}</span>
          <button onclick="Auth.logout()" class="btn btn-sm btn-outline">Logout</button>
        </div>
      `;
        }
    }
};

// Initialize auth on page load
document.addEventListener('DOMContentLoaded', () => {
    Auth.init();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Auth;
}
