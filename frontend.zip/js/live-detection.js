// Live Detection Page Logic - Microplastic Detection Platform

let isDetecting = false;
let detectionInterval = null;
let sessionStartTime = null;
let frameCount = 0;
let totalDetections = 0;
let peakDetections = 0;
let lastFrameTime = Date.now();
let fps = 0;

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    // Hide video, show placeholder
    document.getElementById('liveVideo').style.display = 'none';
    document.getElementById('videoPlaceholder').style.display = 'flex';
});

/**
 * Start live detection
 */
async function startLiveDetection() {
    console.log('🔵 Start Detection button clicked');

    const video = document.getElementById('liveVideo');
    const placeholder = document.getElementById('videoPlaceholder');
    const startButton = document.getElementById('startButton');
    const stopButton = document.getElementById('stopButton');
    const statusIndicator = document.getElementById('statusIndicator');
    const statusText = document.getElementById('statusText');

    if (!video || !placeholder || !startButton || !stopButton) {
        console.error('❌ Required DOM elements not found!');
        alert('Error: Required UI elements not found on page');
        return;
    }

    try {
        statusText.textContent = 'Requesting camera permission...';
        if (statusIndicator) statusIndicator.style.background = 'var(--alert-warning)';

        console.log('📹 Requesting camera access...');

        // Request camera
        const stream = await navigator.mediaDevices.getUserMedia({
            video: {
                width: { ideal: 1280 },
                height: { ideal: 720 },
                facingMode: 'user'
            }
        });

        video.srcObject = stream;
        await new Promise(resolve => {
            video.onloadedmetadata = () => {
                video.play();
                resolve();
            };
        });

        placeholder.style.display = 'none';
        video.style.display = 'block';

        startButton.classList.add('hidden');
        stopButton.classList.remove('hidden');

        if (statusIndicator) {
            statusIndicator.classList.remove('hidden');
            statusIndicator.style.background = 'var(--alert-success)';
            statusIndicator.classList.add('pulse');
        }

        statusText.textContent = 'Live Detection Active ✓';

        isDetecting = true;
        sessionStartTime = Date.now();
        frameCount = 0;
        totalDetections = 0;
        peakDetections = 0;
        lastFrameTime = Date.now();

        console.log('🚀 Starting detection loop...');
        runDetectionLoop();
        updateSessionInfo();

        if (window.Utils && Utils.showToast) {
            Utils.showToast('✅ Live detection started', 'success');
        }

    } catch (error) {
        console.error('❌ Error in startLiveDetection:', error);
        alert('Camera Error: ' + error.message);
    }
}

/**
 * Stop live detection
 */
function stopLiveDetection() {
    const video = document.getElementById('liveVideo');
    const placeholder = document.getElementById('videoPlaceholder');
    const startButton = document.getElementById('startButton');
    const stopButton = document.getElementById('stopButton');
    const statusIndicator = document.getElementById('statusIndicator');
    const statusText = document.getElementById('statusText');

    isDetecting = false;
    if (detectionInterval) clearInterval(detectionInterval);

    if (window.Camera) Camera.stop();

    const canvas = document.getElementById('overlayCanvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    }

    video.style.display = 'none';
    placeholder.style.display = 'flex';
    stopButton.classList.add('hidden');
    startButton.classList.remove('hidden');
    statusIndicator.classList.add('hidden');
    statusIndicator.classList.remove('pulse');
    statusText.textContent = 'Stopped';

    document.getElementById('liveCount').textContent = '0';
    document.getElementById('fpsCounter').textContent = '0';

    if (window.Utils) Utils.showToast('Live detection stopped', 'info');
}

/**
 * Detection loop
 */
async function runDetectionLoop() {
    if (!isDetecting) return;

    const video = document.getElementById('liveVideo');
    const canvas = document.getElementById('overlayCanvas');

    try {
        const frameData = Camera.captureFrame(video);
        const response = await API.startLiveDetection(frameData);

        if (response && response.success) {
            const { detections, count } = response.data;

            frameCount++;
            totalDetections += count;
            peakDetections = Math.max(peakDetections, count);

            const now = Date.now();
            fps = Math.round(1000 / (now - lastFrameTime));
            lastFrameTime = now;

            updateLiveStats(detections, count);
            drawLiveOverlay(canvas, video, detections);
        }
    } catch (error) {
        console.error('Detection error:', error);
    }

    setTimeout(runDetectionLoop, CONFIG.DETECTION.LIVE_DETECTION_INTERVAL);
}

/**
 * Update stats
 */
function updateLiveStats(detections, count) {
    document.getElementById('liveCount').textContent = count;
    document.getElementById('fpsCounter').textContent = fps;
}

/**
 * Draw overlay
 */
function drawLiveOverlay(canvas, video, detections) {
    const ctx = canvas.getContext('2d');

    // Ensure canvas dimensions match video
    if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        console.log(`📏 Resized canvas to ${canvas.width}x${canvas.height}`);
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Debug: Draw a test rectangle to ensure canvas is visible
    // ctx.strokeStyle = 'red';
    // ctx.lineWidth = 5;
    // ctx.strokeRect(10, 10, 100, 100);

    if (detections.length > 0) {
        console.log(`🎨 Drawing ${detections.length} detections...`, detections[0]);
    }

    detections.forEach(det => {
        let x, y, w, h;

        // Handle array format [x1, y1, x2, y2]
        if (det.bbox && Array.isArray(det.bbox)) {
            const [x1, y1, x2, y2] = det.bbox;
            x = x1;
            y = y1;
            w = x2 - x1;
            h = y2 - y1;
        } else if (det.box) {
            // Handle object format {x, y, width, height}
            x = det.box.x;
            y = det.box.y;
            w = det.box.width;
            h = det.box.height;
        } else {
            return; // Skip invalid detection
        }

        // Determine color based on confidence
        let color = '#e74c3c'; // Red (Low)
        if (det.confidence >= 0.8) color = '#2ecc71'; // Green (High)
        else if (det.confidence >= 0.6) color = '#f39c12'; // Orange (Medium)

        // Draw Box
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.strokeRect(x, y, w, h);

        // Draw Background for Label
        const label = det.label || (det.class === 0 ? 'Microplastic' : 'Unknown');
        const text = `${label} ${Math.round(det.confidence * 100)}%`;

        ctx.font = 'bold 16px Inter, sans-serif';
        const textWidth = ctx.measureText(text).width;

        ctx.fillStyle = color;
        ctx.fillRect(x, y - 30, textWidth + 16, 30);

        // Draw Text
        ctx.fillStyle = '#ffffff';
        ctx.fillText(text, x + 8, y - 8);
    });
}

/**
 * Session info
 */
function updateSessionInfo() {
    if (!isDetecting) return;
    setTimeout(updateSessionInfo, 1000);
}

/**
 * Cleanup
 */
window.addEventListener('beforeunload', () => {
    if (isDetecting) stopLiveDetection();
});

/* 🔥 REQUIRED: expose functions globally */
window.startLiveDetection = startLiveDetection;
window.stopLiveDetection = stopLiveDetection;
