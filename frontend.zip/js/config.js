// Configuration - Microplastic Detection Platform

const CONFIG = {
  API: {
    BASE_URL: 'http://localhost:8000',
    ENDPOINTS: {
      DETECT: '/detect',
      LIVE_DETECT: '/detect-frame',
      SAVE_RESULT: '/results',
      GET_RESULTS: '/results',
      MAP_DATA: '/map-data',
      DASHBOARD_STATS: '/dashboard/stats',
      AUTH_LOGIN: '/auth/login',
      AUTH_LOGOUT: '/auth/logout',
      AUTH_VERIFY: '/auth/verify'
    }
  },

  MAPS: {
    API_KEY: 'YOUR_GOOGLE_MAPS_API_KEY',
    DEFAULT_CENTER: { lat: 20.5937, lng: 78.9629 },
    DEFAULT_ZOOM: 5
  },

  DETECTION: {
    CONFIDENCE_THRESHOLD: 0.5,
    LIVE_DETECTION_INTERVAL: 250,
    ACCEPTED_FORMATS: ['image/jpeg', 'image/png', 'image/jpg'],
    MAX_IMAGE_SIZE: 5242880, // 5MB in bytes
    BOUNDING_BOX_COLORS: {
      HIGH: '#2ecc71',
      MEDIUM: '#f39c12',
      LOW: '#e74c3c'
    }
  },

  WATER_STATUS: {
    CLEAN: { label: 'Clean Water', icon: '✅', badge: 'success', min: 0, max: 0 },
    LOW: { label: 'Low Contamination', icon: '⚠️', badge: 'warning', min: 1, max: 50 },
    HIGH: { label: 'High Contamination', icon: '🚨', badge: 'danger', min: 51, max: Infinity }
  },

  CAMERA: {
    VIDEO_CONSTRAINTS: {
      facingMode: 'user',
      width: { ideal: 1280 },
      height: { ideal: 720 }
    }
  },

  STORAGE: {
    AUTH_TOKEN: 'microplastic_auth_token',
    USER_DATA: 'microplastic_user_data',
    DETECTION_HISTORY: 'microplastic_detection_history'
  },

  CHART_COLORS: {
    primary: '#0ea5e9',
    secondary: '#8b5cf6',
    info: '#3b82f6',
    warning: '#f59e0b',
    danger: '#ef4444'
  }
};

/* 🔥 THIS LINE IS THE KEY FIX */
window.CONFIG = CONFIG;

/* Optional: for Node.js / bundlers */
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CONFIG;
}
