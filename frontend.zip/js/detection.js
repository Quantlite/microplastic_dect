// Detection Page Logic - Microplastic Detection Platform

let currentImage = null;
let currentImageFile = null;
let currentDetections = null;

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    setupFileUpload();
});

/**
 * Setup file upload drag and drop
 */
function setupFileUpload() {
    const fileUpload = document.getElementById('fileUpload');
    const imageInput = document.getElementById('imageInput');

    if (!fileUpload || !imageInput) return;

    // Make file upload clickable
    fileUpload.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        imageInput.click();
    });

    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        fileUpload.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });

    // Highlight drop area when item is dragged over it
    ['dragenter', 'dragover'].forEach(eventName => {
        fileUpload.addEventListener(eventName, () => {
            fileUpload.classList.add('drag-over');
        }, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        fileUpload.addEventListener(eventName, () => {
            fileUpload.classList.remove('drag-over');
        }, false);
    });

    // Handle dropped files
    fileUpload.addEventListener('drop', (e) => {
        const dt = e.dataTransfer;
        const files = dt.files;

        if (files.length > 0) {
            handleImageFile(files[0]);
        }
    }, false);
}

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

/**
 * Handle image upload from file input
 */
function handleImageUpload(event) {
    console.log('Image upload triggered', event);
    const file = event.target.files[0];
    if (file) {
        console.log('File selected:', file.name, file.type, file.size);
        handleImageFile(file);
        // Reset input value to allow selecting the same file again
        event.target.value = '';
    }
}

/**
 * Process uploaded image file
 */
async function handleImageFile(file) {
    console.log('Processing file:', file.name);

    // Validate file
    const validation = Utils.validateImageFile(file);
    console.log('Validation result:', validation);

    if (!validation.valid) {
        const errorMsg = validation.errors.join(', ');
        console.error('Validation failed:', errorMsg);
        Utils.showToast(errorMsg, 'danger');
        return;
    }

    try {
        Utils.showLoading('Loading image...');

        // Store the file for backend
        currentImageFile = file;

        // Convert to base64 for preview
        const imageData = await Utils.imageToBase64(file);
        console.log('Image converted to base64');

        // Load image
        const img = await Utils.loadImage(imageData);
        console.log('Image loaded:', img.width, 'x', img.height);

        // Display image
        displayImage(img, imageData);

        Utils.hideLoading();
        Utils.showToast('Image loaded successfully', 'success');
    } catch (error) {
        console.error('Error loading image:', error);
        Utils.hideLoading();
        Utils.showToast('Error loading image: ' + error.message, 'danger');
    }
}

/**
 * Display image on canvas
 */
function displayImage(img, imageData) {
    currentImage = { img, data: imageData };

    const canvas = document.getElementById('imageCanvas');
    const ctx = canvas.getContext('2d');

    // Set canvas size
    canvas.width = img.width;
    canvas.height = img.height;

    // Draw image
    ctx.drawImage(img, 0, 0);

    // Show preview section
    document.getElementById('imagePreviewSection').classList.remove('hidden');

    // Hide results section
    document.getElementById('resultsSection').classList.add('hidden');
}

/**
 * Open camera modal
 */
async function openCameraModal() {
    const modal = document.getElementById('cameraModal');
    const video = document.getElementById('cameraVideo');
    const errorDiv = document.getElementById('cameraError');

    modal.classList.remove('hidden');
    errorDiv.classList.add('hidden');

    try {
        await Camera.requestAccess(video);
    } catch (error) {
        console.error('Camera error:', error);
        errorDiv.textContent = error.message;
        errorDiv.classList.remove('hidden');
    }
}

/**
 * Close camera modal
 */
function closeCameraModal(event) {
    if (event && event.target !== event.currentTarget) return;

    const modal = document.getElementById('cameraModal');
    modal.classList.add('hidden');

    Camera.stop();
}

/**
 * Capture image from camera
 */
function captureFromCamera() {
    const video = document.getElementById('cameraVideo');
    const canvas = document.getElementById('cameraCanvas');

    try {
        const imageData = Camera.captureImage(video, canvas);

        // Load captured image
        Utils.loadImage(imageData).then(img => {
            displayImage(img, imageData);
            closeCameraModal();
            Utils.showToast('Photo captured successfully', 'success');
        });
    } catch (error) {
        console.error('Capture error:', error);
    }
}

/**
 * Clear current image
 */
function clearImage() {
    currentImage = null;
    currentImageFile = null;
    currentDetections = null;

    document.getElementById('imagePreviewSection').classList.add('hidden');
    document.getElementById('resultsSection').classList.add('hidden');
    document.getElementById('imageInput').value = '';
}

/**
 * Run detection on current image
 */
async function runDetection() {
    if (!currentImageFile) {
        Utils.showToast('Please upload an image first', 'warning');
        return;
    }

    const button = document.getElementById('detectButton');
    button.disabled = true;
    button.innerHTML = '<span class="spinner"></span> Detecting...';

    try {
        Utils.showLoading('Analyzing image for microplastics...');

        // Call detection API with the actual file
        const response = await API.detectMicroplastics(currentImageFile);

        if (response.success) {
            currentDetections = response.data;
            displayResults(response.data);
            Utils.showToast('Detection completed successfully', 'success');
        } else {
            Utils.showToast(response.error || 'Detection failed', 'danger');
        }
    } catch (error) {
        console.error('Detection error:', error);
        Utils.showToast('Error during detection', 'danger');
    } finally {
        Utils.hideLoading();
        button.disabled = false;
        button.innerHTML = '🔍 Run Detection';
    }
}

/**
 * Display detection results
 */
function displayResults(data) {
    const { detections, count, timestamp } = data;

    // Calculate statistics
    const stats = Utils.calculateStats(detections);
    const waterStatus = Utils.getWaterStatus(count);

    // Update count
    document.getElementById('resultCount').textContent = count;

    // Update size
    if (count > 0) {
        document.getElementById('resultSize').textContent = stats.avgSize.toFixed(0);
        document.getElementById('resultSizeDetails').textContent =
            `${stats.minSize.toFixed(0)} / ${stats.avgSize.toFixed(0)} / ${stats.maxSize.toFixed(0)} μm`;
    } else {
        document.getElementById('resultSize').textContent = '-';
        document.getElementById('resultSizeDetails').textContent = 'No detections';
    }

    // Update confidence
    if (count > 0) {
        document.getElementById('resultConfidence').textContent =
            Utils.formatPercentage(stats.avgConfidence);
    } else {
        document.getElementById('resultConfidence').textContent = '-';
    }

    // Update timestamp
    document.getElementById('resultTimestamp').textContent =
        'Detected on ' + Utils.formatDate(timestamp);

    // Update water status badge
    const badge = document.getElementById('waterStatusBadge');
    badge.className = `badge badge-${waterStatus.badge}`;
    badge.style.fontSize = 'var(--text-lg)';
    badge.style.padding = 'var(--space-4) var(--space-8)';
    badge.textContent = `${waterStatus.icon} ${waterStatus.label}`;

    // Draw detections on canvas
    const resultCanvas = document.getElementById('resultCanvas');
    Utils.drawDetections(resultCanvas, currentImage.img, detections);

    // Show results section
    document.getElementById('resultsSection').classList.remove('hidden');

    // Scroll to results
    document.getElementById('resultsSection').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
}

/**
 * Save detection result
 */
async function saveResult() {
    if (!currentDetections) {
        Utils.showToast('No detection results to save', 'warning');
        return;
    }

    const location = document.getElementById('resultLocation').value;
    const waterType = document.getElementById('resultWaterType').value;

    const resultData = {
        ...currentDetections,
        location: location || 'Unknown',
        waterType: waterType,
        image: currentImage.data
    };

    try {
        Utils.showLoading('Saving result...');

        const response = await API.saveDetectionResult(resultData);

        if (response.success) {
            Utils.showToast('Result saved successfully', 'success');
        }
    } catch (error) {
        console.error('Save error:', error);
    } finally {
        Utils.hideLoading();
    }
}
