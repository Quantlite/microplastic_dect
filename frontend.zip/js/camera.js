// Camera Utilities - Microplastic Detection Platform

const Camera = {
    stream: null,
    videoElement: null,

    /**
     * Check if camera is supported
     */
    isSupported() {
        return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
    },

    /**
     * Request camera access
     */
    async requestAccess(videoElement, constraints = CONFIG.CAMERA.VIDEO_CONSTRAINTS) {
        if (!this.isSupported()) {
            throw new Error('Camera not supported in this browser');
        }

        try {
            this.stream = await navigator.mediaDevices.getUserMedia(constraints);
            this.videoElement = videoElement;

            if (videoElement) {
                videoElement.srcObject = this.stream;
                await videoElement.play();
            }

            return this.stream;
        } catch (error) {
            console.error('Error accessing camera:', error);

            if (error.name === 'NotAllowedError') {
                throw new Error('Camera access denied. Please allow camera permissions.');
            } else if (error.name === 'NotFoundError') {
                throw new Error('No camera found on this device.');
            } else {
                throw new Error('Error accessing camera: ' + error.message);
            }
        }
    },

    /**
     * Capture still image from video stream
     */
    captureImage(videoElement, canvas) {
        if (!videoElement || !canvas) {
            throw new Error('Video element and canvas are required');
        }

        const ctx = canvas.getContext('2d');

        // Set canvas size to match video
        canvas.width = videoElement.videoWidth;
        canvas.height = videoElement.videoHeight;

        // Draw current video frame to canvas
        ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);

        // Return as data URL
        return canvas.toDataURL('image/jpeg', 0.9);
    },

    /**
     * Capture frame for live detection
     */
    captureFrame(videoElement) {
        if (!videoElement) {
            throw new Error('Video element is required');
        }

        const canvas = document.createElement('canvas');
        canvas.width = videoElement.videoWidth;
        canvas.height = videoElement.videoHeight;

        const ctx = canvas.getContext('2d');
        ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);

        return canvas.toDataURL('image/jpeg', 0.8);
    },

    /**
     * Stop camera stream
     */
    stop() {
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }

        if (this.videoElement) {
            this.videoElement.srcObject = null;
            this.videoElement = null;
        }
    },

    /**
     * Switch camera (front/back)
     */
    async switchCamera() {
        const currentFacingMode = this.stream?.getVideoTracks()[0]?.getSettings()?.facingMode;
        const newFacingMode = currentFacingMode === 'user' ? 'environment' : 'user';

        this.stop();

        const constraints = {
            video: {
                ...CONFIG.CAMERA.VIDEO_CONSTRAINTS.video,
                facingMode: newFacingMode
            }
        };

        return await this.requestAccess(this.videoElement, constraints);
    },

    /**
     * Get available cameras
     */
    async getDevices() {
        if (!this.isSupported()) {
            return [];
        }

        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            return devices.filter(device => device.kind === 'videoinput');
        } catch (error) {
            console.error('Error getting camera devices:', error);
            return [];
        }
    },

    /**
     * Get default webcam (prefer front-facing camera)
     */
    async getDefaultWebcam() {
        const devices = await this.getDevices();
        
        if (devices.length === 0) {
            throw new Error('No webcam found on this device');
        }

        // Try to find a front-facing camera first
        const frontCamera = devices.find(device => 
            device.label && device.label.toLowerCase().includes('front')
        );

        if (frontCamera) {
            return frontCamera;
        }

        // If no front camera found, return the first camera
        return devices[0];
    },

    /**
     * Connect to default webcam
     */
    async connectDefaultWebcam(videoElement) {
        try {
            const webcam = await this.getDefaultWebcam();
            console.log('Connecting to webcam:', webcam.label || 'Default Camera');
            return await this.selectCamera(webcam.deviceId, videoElement);
        } catch (error) {
            console.error('Error connecting to default webcam:', error);
            // Fallback to standard getUserMedia if device selection fails
            return await this.requestAccess(videoElement);
        }
    },

    /**
     * Select specific camera by device ID
     */
    async selectCamera(deviceId, videoElement) {
        const constraints = {
            video: {
                deviceId: { exact: deviceId },
                width: { ideal: 1280 },
                height: { ideal: 720 }
            }
        };

        return await this.requestAccess(videoElement, constraints);
    },

    /**
     * Take photo with countdown
     */
    async takePhotoWithCountdown(videoElement, canvas, countdown = 3, onTick) {
        return new Promise((resolve) => {
            let count = countdown;

            const interval = setInterval(() => {
                if (onTick) onTick(count);

                if (count === 0) {
                    clearInterval(interval);
                    const imageData = this.captureImage(videoElement, canvas);
                    resolve(imageData);
                }

                count--;
            }, 1000);
        });
    },

    /**
     * Get camera resolution
     */
    getResolution(videoElement) {
        if (!videoElement) return null;

        return {
            width: videoElement.videoWidth,
            height: videoElement.videoHeight
        };
    },

    /**
     * Check if camera is active
     */
    isActive() {
        return this.stream !== null && this.stream.active;
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Camera;
}
