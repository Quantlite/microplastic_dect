// Dashboard Page Logic - Microplastic Detection Platform

let trendChart = null;
let locationChart = null;
let waterTypeChart = null;
let dashboardData = null;

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    loadDashboardData();
});

/**
 * Load dashboard data
 */
async function loadDashboardData() {
    try {
        Utils.showLoading('Loading dashboard data...');

        const response = await API.getDashboardStats();

        if (response.success) {
            dashboardData = response.data;
            updateSummaryCards(dashboardData.summary);
            initializeCharts(dashboardData.charts);
            loadRecentDetections();
        }

        Utils.hideLoading();
    } catch (error) {
        console.error('Error loading dashboard:', error);
        Utils.hideLoading();
        // Silent fail - use default values
    }
}

/**
 * Update summary cards
 */
function updateSummaryCards(summary) {
    document.getElementById('totalSamples').textContent = summary.totalSamples;
    document.getElementById('samplesTrend').textContent = `+${Math.floor(summary.totalSamples * 0.15)} this period`;
    document.getElementById('avgContamination').textContent = summary.avgContamination;
    document.getElementById('highRiskLocations').textContent = summary.highRiskLocations;
    document.getElementById('trendValue').textContent = summary.trend;
}

/**
 * Initialize all charts
 */
function initializeCharts(chartsData) {
    initTrendChart(chartsData.trend);
    initLocationChart(chartsData.locations);
    initWaterTypeChart(chartsData.waterTypes);
}

/**
 * Initialize trend chart
 */
function initTrendChart(data) {
    const ctx = document.getElementById('trendChart');

    if (trendChart) {
        trendChart.destroy();
    }

    trendChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Avg Microplastics',
                data: data.data,
                borderColor: CONFIG.CHART_COLORS.primary,
                backgroundColor: CONFIG.CHART_COLORS.primary + '20',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointRadius: 5,
                pointBackgroundColor: CONFIG.CHART_COLORS.primary,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    titleFont: {
                        size: 14,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 13
                    },
                    callbacks: {
                        label: function (context) {
                            return 'Avg: ' + context.parsed.y + ' particles';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    ticks: {
                        font: {
                            size: 12
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 12
                        }
                    }
                }
            }
        }
    });
}

/**
 * Initialize location chart
 */
function initLocationChart(data) {
    const ctx = document.getElementById('locationChart');

    if (locationChart) {
        locationChart.destroy();
    }

    locationChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Avg Contamination',
                data: data.data,
                backgroundColor: [
                    CONFIG.CHART_COLORS.primary,
                    CONFIG.CHART_COLORS.secondary,
                    CONFIG.CHART_COLORS.info,
                    CONFIG.CHART_COLORS.warning,
                    CONFIG.CHART_COLORS.danger
                ],
                borderRadius: 8,
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    titleFont: {
                        size: 14,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 13
                    },
                    callbacks: {
                        label: function (context) {
                            return 'Avg: ' + context.parsed.y + ' particles';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    ticks: {
                        font: {
                            size: 12
                        }
                    }
                },
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 12
                        }
                    }
                }
            }
        }
    });
}

/**
 * Initialize water type chart
 */
function initWaterTypeChart(data) {
    const ctx = document.getElementById('waterTypeChart');

    if (waterTypeChart) {
        waterTypeChart.destroy();
    }

    waterTypeChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.labels,
            datasets: [{
                data: data.data,
                backgroundColor: [
                    CONFIG.CHART_COLORS.primary,
                    CONFIG.CHART_COLORS.secondary,
                    CONFIG.CHART_COLORS.info,
                    CONFIG.CHART_COLORS.warning
                ],
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        font: {
                            size: 13
                        },
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    titleFont: {
                        size: 14,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 13
                    },
                    callbacks: {
                        label: function (context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((context.parsed / total) * 100).toFixed(1);
                            return context.label + ': ' + context.parsed + ' (' + percentage + '%)';
                        }
                    }
                }
            }
        }
    });
}

/**
 * Load recent detections
 */
async function loadRecentDetections() {
    try {
        const response = await API.getDetectionResults();

        if (response.success) {
            const recentData = response.data.slice(0, 5);
            renderRecentDetections(recentData);
        }
    } catch (error) {
        console.error('Error loading recent detections:', error);
    }
}

/**
 * Render recent detections list
 */
function renderRecentDetections(detections) {
    const container = document.getElementById('recentDetections');

    if (detections.length === 0) {
        container.innerHTML = `
      <div class="text-center" style="padding: var(--space-8); color: var(--text-tertiary);">
        <div style="font-size: 48px; margin-bottom: var(--space-4); opacity: 0.3;">📊</div>
        <p>No recent detections found</p>
      </div>
    `;
        return;
    }

    container.innerHTML = detections.map(detection => {
        const waterStatus = Utils.getWaterStatus(detection.count);

        return `
      <div class="flex items-center justify-between" style="padding: var(--space-4); border-bottom: 1px solid var(--border-light); transition: background var(--transition-fast);" onmouseenter="this.style.background='var(--background-alt)'" onmouseleave="this.style.background='transparent'">
        <div class="flex items-center gap-4">
          <div style="width: 50px; height: 50px; background: linear-gradient(135deg, var(--ocean-blue-500), var(--ocean-blue-600)); border-radius: var(--radius-lg); display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; font-size: var(--text-xl);">
            ${detection.count}
          </div>
          <div>
            <div style="font-weight: 500; margin-bottom: var(--space-1);">${detection.location || 'Unknown Location'}</div>
            <div style="font-size: var(--text-sm); color: var(--text-tertiary);">
              ${Utils.formatDate(detection.timestamp, 'short')} • ${detection.waterType ? detection.waterType.charAt(0).toUpperCase() + detection.waterType.slice(1) : 'Unknown'}
            </div>
          </div>
        </div>
        <div class="badge badge-${waterStatus.badge}">
          ${waterStatus.icon} ${waterStatus.label}
        </div>
      </div>
    `;
    }).join('');
}

/**
 * Apply dashboard filters
 */
function applyDashboardFilters() {
    const dateFilter = document.getElementById('dashboardDateFilter').value;
    const locationFilter = document.getElementById('dashboardLocationFilter').value;
    const waterTypeFilter = document.getElementById('dashboardWaterTypeFilter').value;

    Utils.showToast('Filters applied - refreshing data...', 'info');

    // In production, this would fetch filtered data from API
    setTimeout(() => {
        loadDashboardData();
    }, 500);
}

/**
 * Reset dashboard filters
 */
function resetDashboardFilters() {
    document.getElementById('dashboardDateFilter').value = '30';
    document.getElementById('dashboardLocationFilter').value = 'all';
    document.getElementById('dashboardWaterTypeFilter').value = 'all';

    applyDashboardFilters();
}

/**
 * Refresh dashboard
 */
function refreshDashboard() {
    loadDashboardData();
    Utils.showToast('Dashboard refreshed', 'success');
}
