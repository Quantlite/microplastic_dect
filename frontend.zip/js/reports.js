// Reports Page Logic - Microplastic Detection Platform

let reportData = null;

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
    loadReportData();
    updateReportDate();
    loadReportHistory();
});

/**
 * Update report date
 */
function updateReportDate() {
    document.getElementById('reportDate').textContent = Utils.formatDate(new Date());
}

/**
 * Load report data
 */
async function loadReportData() {
    try {
        Utils.showLoading('Loading report data...');

        // Get dashboard stats
        const statsResponse = await API.getDashboardStats();

        // Get detection results
        const detectionsResponse = await API.getDetectionResults();

        if (statsResponse.success && detectionsResponse.success) {
            reportData = {
                stats: statsResponse.data.summary,
                detections: detectionsResponse.data
            };

            updateReportPreview();
        }

        Utils.hideLoading();
    } catch (error) {
        console.error('Error loading report data:', error);
        Utils.hideLoading();
        // Silent fail - reports will use empty/default data
    }
}

/**
 * Update report preview
 */
function updateReportPreview() {
    if (!reportData) return;

    // Update summary stats
    document.getElementById('reportTotalSamples').textContent = reportData.stats.totalSamples;
    document.getElementById('reportAvgContamination').textContent = reportData.stats.avgContamination;
    document.getElementById('reportHighRisk').textContent = reportData.stats.highRiskLocations;

    // Update detections list
    updateDetectionsList();

    // Show/hide sections based on settings
    const includeSummary = document.getElementById('includeSummary')?.checked;
    const includeDetections = document.getElementById('includeDetections')?.checked;
    const includeMap = document.getElementById('includeMap')?.checked;
    const includeImages = document.getElementById('includeImages')?.checked;

    // Toggle visibility (simplified for preview)
    if (includeImages && reportData.detections.length > 0 && reportData.detections[0].image) {
        document.getElementById('reportImageSection')?.classList.remove('hidden');
        displayReportImage(reportData.detections[0]);
    } else {
        document.getElementById('reportImageSection')?.classList.add('hidden');
    }
}

/**
 * Update detections list in report
 */
function updateDetectionsList() {
    const container = document.getElementById('reportDetectionsList');
    const detections = reportData.detections.slice(0, 10); // Show top 10

    if (detections.length === 0) {
        container.innerHTML = '<p style="color: var(--text-tertiary); text-align: center; padding: var(--space-8);">No detections found</p>';
        return;
    }

    container.innerHTML = `
    <table style="width: 100%; border-collapse: collapse; font-size: var(--text-sm);">
      <thead>
        <tr style="background: var(--neutral-gray-100); border-bottom: 2px solid var(--border);">
          <th style="padding: var(--space-3); text-align: left;">Date</th>
          <th style="padding: var(--space-3); text-align: left;">Location</th>
          <th style="padding: var(--space-3); text-align: left;">Water Type</th>
          <th style="padding: var(--space-3); text-align: center;">Count</th>
          <th style="padding: var(--space-3); text-align: left;">Status</th>
        </tr>
      </thead>
      <tbody>
        ${detections.map(detection => {
        const waterStatus = Utils.getWaterStatus(detection.count);
        return `
            <tr style="border-bottom: 1px solid var(--border-light);">
              <td style="padding: var(--space-3);">${Utils.formatDate(detection.timestamp, 'short')}</td>
              <td style="padding: var(--space-3);">${detection.location || 'Unknown'}</td>
              <td style="padding: var(--space-3); text-transform: capitalize;">${detection.waterType || 'Unknown'}</td>
              <td style="padding: var(--space-3); text-align: center; font-weight: bold; color: var(--primary);">${detection.count}</td>
              <td style="padding: var(--space-3);">
                <span style="display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; background: ${waterStatus.badge === 'success' ? 'var(--nature-green-100)' :
                waterStatus.badge === 'warning' ? '#FFF3CD' :
                    '#F8D7DA'
            }; color: ${waterStatus.badge === 'success' ? 'var(--nature-green-800)' :
                waterStatus.badge === 'warning' ? '#856404' :
                    '#721C24'
            };">
                  ${waterStatus.label}
                </span>
              </td>
            </tr>
          `;
    }).join('')}
      </tbody>
    </table>
  `;
}

/**
 * Display report image
 */
function displayReportImage(detection) {
    if (!detection.image || !detection.detections) return;

    const canvas = document.getElementById('reportImageCanvas');

    Utils.loadImage(detection.image).then(img => {
        Utils.drawDetections(canvas, img, detection.detections);
    }).catch(error => {
        console.error('Error loading report image:', error);
    });
}

/**
 * Generate PDF report
 */
async function generatePDF() {
    try {
        Utils.showLoading('Generating PDF report...');

        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        const margin = 20;
        let yPosition = margin;

        // Header
        doc.setFontSize(24);
        doc.setTextColor(46, 125, 154); // Primary color
        doc.text('Microplastic Detection Report', pageWidth / 2, yPosition, { align: 'center' });

        yPosition += 10;
        doc.setFontSize(10);
        doc.setTextColor(117, 117, 117);
        doc.text(`Generated on ${Utils.formatDate(new Date())}`, pageWidth / 2, yPosition, { align: 'center' });

        yPosition += 15;

        // Line separator
        doc.setDrawColor(46, 125, 154);
        doc.setLineWidth(0.5);
        doc.line(margin, yPosition, pageWidth - margin, yPosition);

        yPosition += 15;

        // Executive Summary
        doc.setFontSize(16);
        doc.setTextColor(46, 125, 154);
        doc.text('Executive Summary', margin, yPosition);

        yPosition += 10;

        doc.setFontSize(11);
        doc.setTextColor(33, 33, 33);

        const summaryData = [
            `Total Samples Analyzed: ${reportData.stats.totalSamples}`,
            `Average Contamination: ${reportData.stats.avgContamination} particles per sample`,
            `High-Risk Locations: ${reportData.stats.highRiskLocations}`,
            `Trend: ${reportData.stats.trend} vs previous period`
        ];

        summaryData.forEach(line => {
            doc.text(line, margin + 5, yPosition);
            yPosition += 7;
        });

        yPosition += 10;

        // Recent Detections
        doc.setFontSize(16);
        doc.setTextColor(46, 125, 154);
        doc.text('Recent Detections', margin, yPosition);

        yPosition += 10;

        doc.setFontSize(9);
        doc.setTextColor(33, 33, 33);

        // Table header
        const tableStartY = yPosition;
        const colWidths = [35, 45, 35, 25, 40];
        const headers = ['Date', 'Location', 'Water Type', 'Count', 'Status'];

        doc.setFillColor(245, 245, 245);
        doc.rect(margin, yPosition, pageWidth - 2 * margin, 8, 'F');

        let xPosition = margin + 2;
        headers.forEach((header, i) => {
            doc.setFont(undefined, 'bold');
            doc.text(header, xPosition, yPosition + 5);
            xPosition += colWidths[i];
        });

        yPosition += 10;

        // Table rows
        const detections = reportData.detections.slice(0, 10);
        detections.forEach((detection, index) => {
            if (yPosition > pageHeight - 30) {
                doc.addPage();
                yPosition = margin;
            }

            const waterStatus = Utils.getWaterStatus(detection.count);

            xPosition = margin + 2;
            doc.setFont(undefined, 'normal');

            doc.text(Utils.formatDate(detection.timestamp, 'short'), xPosition, yPosition + 5);
            xPosition += colWidths[0];

            doc.text(detection.location || 'Unknown', xPosition, yPosition + 5);
            xPosition += colWidths[1];

            doc.text((detection.waterType || 'Unknown').charAt(0).toUpperCase() + (detection.waterType || 'unknown').slice(1), xPosition, yPosition + 5);
            xPosition += colWidths[2];

            doc.text(detection.count.toString(), xPosition, yPosition + 5);
            xPosition += colWidths[3];

            doc.text(waterStatus.label, xPosition, yPosition + 5);

            yPosition += 8;

            // Alternate row background
            if (index % 2 === 1) {
                doc.setFillColor(250, 250, 250);
                doc.rect(margin, yPosition - 8, pageWidth - 2 * margin, 8, 'F');
            }
        });

        // Footer
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text('MicroPlastic AI Detection Platform', pageWidth / 2, pageHeight - 10, { align: 'center' });
        doc.text('© 2026 Environmental Technology Solutions', pageWidth / 2, pageHeight - 5, { align: 'center' });

        // Save PDF
        const reportTitle = document.getElementById('reportTitle').value || 'Microplastic_Report';
        const filename = `${reportTitle.replace(/\s+/g, '_')}_${Date.now()}.pdf`;
        doc.save(filename);

        // Save to history
        saveToHistory(filename);

        Utils.hideLoading();
        Utils.showToast('PDF report generated successfully', 'success');
    } catch (error) {
        console.error('Error generating PDF:', error);
        Utils.hideLoading();
    }
}

/**
 * Print report
 */
function printReport() {
    window.print();
    Utils.showToast('Opening print dialog...', 'info');
}

/**
 * Email report
 */
function emailReport() {
    Utils.showToast('Email functionality would be integrated with backend', 'info');

    // In production, this would:
    // 1. Generate PDF
    // 2. Send to backend
    // 3. Backend sends email with attachment
}

/**
 * Save report to history
 */
function saveToHistory(filename) {
    const history = Utils.storage.get('report_history') || [];

    history.unshift({
        filename,
        date: new Date().toISOString(),
        stats: reportData.stats
    });

    // Keep only last 10
    if (history.length > 10) {
        history.pop();
    }

    Utils.storage.set('report_history', history);
    loadReportHistory();
}

/**
 * Load report history
 */
function loadReportHistory() {
    const history = Utils.storage.get('report_history') || [];
    const container = document.getElementById('reportHistory');

    if (history.length === 0) {
        container.innerHTML = '<p style="color: var(--text-tertiary); font-size: var(--text-sm); text-align: center;">No recent reports</p>';
        return;
    }

    container.innerHTML = history.slice(0, 5).map(report => `
    <div style="padding: var(--space-3); background: var(--background-alt); border-radius: var(--radius-md); cursor: pointer; transition: all var(--transition-fast);" onmouseenter="this.style.background='var(--ocean-blue-50)'" onmouseleave="this.style.background='var(--background-alt)'">
      <div style="font-size: var(--text-sm); font-weight: 500; margin-bottom: var(--space-1); color: var(--primary);">📄 ${report.filename}</div>
      <div style="font-size: var(--text-xs); color: var(--text-tertiary);">${Utils.formatDate(report.date, 'short')}</div>
    </div>
  `).join('');
}
