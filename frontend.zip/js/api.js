// API Service - Microplastic Detection Platform
// Mock implementation ready for backend integration

const API = {
    /**
     * Detect microplastics in image
     */
    async detectMicroplastics(imageFile) {
        try {
            const formData = new FormData();
            formData.append('file', imageFile);

            const response = await fetch(`${CONFIG.API.BASE_URL}${CONFIG.API.ENDPOINTS.DETECT}`, {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Backend error: ${response.status}`);
            }

            const data = await response.json();

            return {
                success: true,
                data: {
                    detections: data.detections || [],
                    count: data.count || 0,
                    status: data.status || 'Unknown',
                    timestamp: new Date().toISOString(),
                    processingTime: data.processingTime || 0
                }
            };
        } catch (error) {
            console.error('Detection error:', error);
            return {
                success: false,
                error: error.message
            };
        }
    },

    /**
     * Start live detection
     */
    async startLiveDetection(frameDataUrl) {
        try {
            // Convert data URL to blob
            const response = await fetch(frameDataUrl);
            const blob = await response.blob();

            const formData = new FormData();
            formData.append('file', blob, 'frame.jpg');

            const response2 = await fetch(`${CONFIG.API.BASE_URL}${CONFIG.API.ENDPOINTS.LIVE_DETECT}`, {
                method: 'POST',
                body: formData,
                timeout: 10000
            });

            if (!response2.ok) {
                throw new Error(`Backend error: ${response2.status}`);
            }

            const data = await response2.json();

            return {
                success: true,
                data: {
                    detections: data.detections || [],
                    count: data.count || 0,
                    status: data.status || 'Unknown',
                    timestamp: new Date().toISOString(),
                    processingTime: data.processingTime || 0
                }
            };
        } catch (error) {
            console.error('Live detection error:', error);
            return {
                success: false,
                error: error.message,
                data: {
                    detections: [],
                    count: 0,
                    timestamp: new Date().toISOString()
                }
            };
        }
    },

    /**
     * Save detection result
     */
    async saveDetectionResult(data) {
        await this._delay(500);

        // Save to local storage
        const history = Utils.storage.get(CONFIG.STORAGE.DETECTION_HISTORY) || [];
        const result = {
            id: Utils.generateId(),
            ...data,
            savedAt: new Date().toISOString()
        };

        history.unshift(result);

        // Keep only last 50 results
        if (history.length > 50) {
            history.pop();
        }

        Utils.storage.set(CONFIG.STORAGE.DETECTION_HISTORY, history);

        return {
            success: true,
            data: result
        };
    },

    /**
     * Get detection results
     */
    async getDetectionResults(filters = {}) {
        await this._delay(300);

        let history = Utils.storage.get(CONFIG.STORAGE.DETECTION_HISTORY) || [];

        // Apply filters
        if (filters.startDate) {
            history = history.filter(r => new Date(r.timestamp) >= new Date(filters.startDate));
        }
        if (filters.endDate) {
            history = history.filter(r => new Date(r.timestamp) <= new Date(filters.endDate));
        }
        if (filters.waterType) {
            history = history.filter(r => r.waterType === filters.waterType);
        }

        return {
            success: true,
            data: history
        };
    },

    /**
     * Get map data
     */
    async getMapData(filters = {}) {
        await this._delay(500);

        // Generate mock map data
        const mockLocations = this._generateMockMapData();

        return {
            success: true,
            data: mockLocations
        };
    },

    /**
     * Get dashboard statistics
     */
    async getDashboardStats(filters = {}) {
        await this._delay(400);

        const history = Utils.storage.get(CONFIG.STORAGE.DETECTION_HISTORY) || [];

        // Calculate stats from history
        const totalSamples = history.length || 15; // Default to 15 if no history
        const avgContamination = history.length > 0
            ? history.reduce((sum, r) => sum + r.count, 0) / history.length
            : 3.5;

        const highRiskLocations = history.filter(r => r.count >= 6).length || 2;

        // Generate trend data
        const trendData = this._generateTrendData();
        const locationData = this._generateLocationData();
        const waterTypeData = this._generateWaterTypeData();

        return {
            success: true,
            data: {
                summary: {
                    totalSamples,
                    avgContamination: avgContamination.toFixed(1),
                    highRiskLocations,
                    trend: '+12%'
                },
                charts: {
                    trend: trendData,
                    locations: locationData,
                    waterTypes: waterTypeData
                }
            }
        };
    },

    /**
     * Authenticate user
     */
    async login(credentials) {
        await this._delay(800);

        // Mock authentication
        if (credentials.email === 'admin@microplastic.com' && credentials.password === 'admin123') {
            const token = 'mock_jwt_token_' + Utils.generateId();
            const userData = {
                id: '1',
                email: credentials.email,
                name: 'Admin User',
                role: 'admin'
            };

            Utils.storage.set(CONFIG.STORAGE.AUTH_TOKEN, token);
            Utils.storage.set(CONFIG.STORAGE.USER_DATA, userData);

            return {
                success: true,
                data: {
                    token,
                    user: userData
                }
            };
        }

        return {
            success: false,
            error: 'Invalid credentials'
        };
    },

    /**
     * Logout user
     */
    async logout() {
        await this._delay(300);

        Utils.storage.remove(CONFIG.STORAGE.AUTH_TOKEN);
        Utils.storage.remove(CONFIG.STORAGE.USER_DATA);

        return {
            success: true
        };
    },

    /**
     * Verify authentication
     */
    async verifyAuth() {
        const token = Utils.storage.get(CONFIG.STORAGE.AUTH_TOKEN);
        const user = Utils.storage.get(CONFIG.STORAGE.USER_DATA);

        if (token && user) {
            return {
                success: true,
                data: { user }
            };
        }

        return {
            success: false,
            error: 'Not authenticated'
        };
    },

    // Helper methods

    _delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    },

    _generateMockDetections(count) {
        const numDetections = count !== undefined ? count : Math.floor(Math.random() * 8) + 1;
        const detections = [];

        for (let i = 0; i < numDetections; i++) {
            detections.push({
                id: Utils.generateId(),
                label: 'Microplastic',
                confidence: 0.6 + Math.random() * 0.4, // 0.6 to 1.0
                box: {
                    x: Math.random() * 500,
                    y: Math.random() * 400,
                    width: 30 + Math.random() * 70,
                    height: 30 + Math.random() * 70
                },
                size: Math.random() * 500 + 50 // 50-550 micrometers
            });
        }

        return detections;
    },

    _generateMockMapData() {
        const locations = [
            { name: 'Mumbai Beach', lat: 19.0760, lng: 72.8777, waterType: 'sea' },
            { name: 'Ganges River', lat: 25.3176, lng: 82.9739, waterType: 'river' },
            { name: 'Chennai Marina', lat: 13.0827, lng: 80.2707, waterType: 'sea' },
            { name: 'Yamuna River', lat: 28.6139, lng: 77.2090, waterType: 'river' },
            { name: 'Goa Beach', lat: 15.2993, lng: 74.1240, waterType: 'sea' },
            { name: 'Bangalore Lake', lat: 12.9716, lng: 77.5946, waterType: 'lake' },
            { name: 'Kolkata Tap Water', lat: 22.5726, lng: 88.3639, waterType: 'tap' },
            { name: 'Delhi Tap Water', lat: 28.7041, lng: 77.1025, waterType: 'tap' }
        ];

        return locations.map(loc => ({
            ...loc,
            id: Utils.generateId(),
            count: Math.floor(Math.random() * 12),
            date: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
            avgSize: Math.random() * 400 + 100
        }));
    },

    _generateTrendData() {
        const labels = [];
        const data = [];

        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            data.push(Math.floor(Math.random() * 5) + 2);
        }

        return { labels, data };
    },

    _generateLocationData() {
        return {
            labels: ['Mumbai', 'Chennai', 'Kolkata', 'Delhi', 'Bangalore'],
            data: [8, 6, 5, 7, 4]
        };
    },

    _generateWaterTypeData() {
        return {
            labels: ['Sea', 'River', 'Lake', 'Tap'],
            data: [35, 30, 20, 15]
        };
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = API;
}
