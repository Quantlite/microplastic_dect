// Utility Functions - Microplastic Detection Platform

const Utils = {
    /**
     * Format date to readable string
     */
    formatDate(date, format = 'full') {
        const d = new Date(date);

        if (format === 'full') {
            return d.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } else if (format === 'short') {
            return d.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        } else if (format === 'time') {
            return d.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        return d.toLocaleDateString();
    },

    /**
     * Format number with commas
     */
    formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    },

    /**
     * Format file size
     */
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    },

    /**
     * Format percentage
     */
    formatPercentage(value, decimals = 1) {
        return `${(value * 100).toFixed(decimals)}%`;
    },

    /**
     * Debounce function
     */
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    /**
     * Throttle function
     */
    throttle(func, limit) {
        let inThrottle;
        return function (...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    },

    /**
     * Generate unique ID
     */
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    },

    /**
     * Validate email
     */
    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    },

    /**
     * Validate image file
     */
    validateImageFile(file) {
        const errors = [];

        if (!file) {
            errors.push('No file selected');
            return { valid: false, errors };
        }

        if (!CONFIG.DETECTION.ACCEPTED_FORMATS.includes(file.type)) {
            errors.push('Invalid file format. Please upload JPG or PNG');
        }

        if (file.size > CONFIG.DETECTION.MAX_IMAGE_SIZE) {
            errors.push(`File size exceeds ${this.formatFileSize(CONFIG.DETECTION.MAX_IMAGE_SIZE)}`);
        }

        return {
            valid: errors.length === 0,
            errors
        };
    },

    /**
     * Get water status based on microplastic count
     */
    getWaterStatus(count) {
        if (count === 0) {
            return CONFIG.WATER_STATUS.CLEAN;
        } else if (count >= CONFIG.WATER_STATUS.LOW.min && count <= CONFIG.WATER_STATUS.LOW.max) {
            return CONFIG.WATER_STATUS.LOW;
        } else {
            return CONFIG.WATER_STATUS.HIGH;
        }
    },

    /**
     * Draw bounding box on canvas
     */
    drawBoundingBox(ctx, box, label, confidence) {
        const { x, y, width, height } = box;

        // Determine color based on confidence
        let color;
        if (confidence >= 0.8) {
            color = CONFIG.DETECTION.BOUNDING_BOX_COLORS.HIGH;
        } else if (confidence >= 0.6) {
            color = CONFIG.DETECTION.BOUNDING_BOX_COLORS.MEDIUM;
        } else {
            color = CONFIG.DETECTION.BOUNDING_BOX_COLORS.LOW;
        }

        // Draw rectangle
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.strokeRect(x, y, width, height);

        // Draw label background
        const labelText = `${label} ${(confidence * 100).toFixed(0)}%`;
        ctx.font = '14px Inter, sans-serif';
        const textWidth = ctx.measureText(labelText).width;

        ctx.fillStyle = color;
        ctx.fillRect(x, y - 25, textWidth + 10, 25);

        // Draw label text
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(labelText, x + 5, y - 7);
    },

    /**
     * Draw all detections on canvas
     */
    drawDetections(canvas, image, detections) {
        const ctx = canvas.getContext('2d');

        // Set canvas size to match image
        canvas.width = image.width;
        canvas.height = image.height;

        // Draw image
        ctx.drawImage(image, 0, 0);

        // Draw each detection
        detections.forEach(detection => {
            this.drawBoundingBox(ctx, detection.box, detection.label, detection.confidence);
        });
    },

    /**
     * Convert image to base64
     */
    imageToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    },

    /**
     * Load image from URL
     */
    loadImage(url) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => resolve(img);
            img.onerror = reject;
            img.src = url;
        });
    },

    /**
     * Show toast notification
     */
    showToast(message, type = 'info', duration = 3000) {
        const toast = document.createElement('div');
        toast.className = `alert alert-${type} toast`;
        toast.style.cssText = `
      position: fixed;
      top: 100px;
      right: 20px;
      z-index: 9999;
      min-width: 300px;
      animation: slideDown 0.3s ease-out;
    `;
        toast.textContent = message;

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'fadeOut 0.3s ease-out';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },

    /**
     * Show loading overlay
     */
    showLoading(message = 'Loading...') {
        const overlay = document.createElement('div');
        overlay.id = 'loading-overlay';
        overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.7);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      color: white;
      gap: 20px;
    `;

        overlay.innerHTML = `
      <div class="spinner" style="width: 50px; height: 50px; border-width: 5px;"></div>
      <div style="font-size: 18px; font-weight: 500;">${message}</div>
    `;

        document.body.appendChild(overlay);
    },

    /**
     * Hide loading overlay
     */
    hideLoading() {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.remove();
        }
    },

    /**
     * Local storage helpers
     */
    storage: {
        set(key, value) {
            try {
                localStorage.setItem(key, JSON.stringify(value));
                return true;
            } catch (e) {
                console.error('Error saving to localStorage:', e);
                return false;
            }
        },

        get(key) {
            try {
                const item = localStorage.getItem(key);
                return item ? JSON.parse(item) : null;
            } catch (e) {
                console.error('Error reading from localStorage:', e);
                return null;
            }
        },

        remove(key) {
            try {
                localStorage.removeItem(key);
                return true;
            } catch (e) {
                console.error('Error removing from localStorage:', e);
                return false;
            }
        },

        clear() {
            try {
                localStorage.clear();
                return true;
            } catch (e) {
                console.error('Error clearing localStorage:', e);
                return false;
            }
        }
    },

    /**
     * Calculate statistics
     */
    calculateStats(detections) {
        if (!detections || detections.length === 0) {
            return {
                count: 0,
                avgSize: 0,
                minSize: 0,
                maxSize: 0,
                avgConfidence: 0
            };
        }

        const sizes = detections.map(d => d.size || 0);
        const confidences = detections.map(d => d.confidence || 0);

        return {
            count: detections.length,
            avgSize: sizes.reduce((a, b) => a + b, 0) / sizes.length,
            minSize: Math.min(...sizes),
            maxSize: Math.max(...sizes),
            avgConfidence: confidences.reduce((a, b) => a + b, 0) / confidences.length
        };
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Utils;
}
