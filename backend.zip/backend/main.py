from fastapi import FastAPI, UploadFile, File, WebSocket
from fastapi.middleware.cors import CORSMiddleware
import cv2
import numpy as np
import base64
from ultralytics import YOLO

# ----------------------------
# App initialization
# ----------------------------
app = FastAPI(
    title="Microplastic Detection API",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----------------------------
# Load YOLO model ONCE
# ----------------------------
MODEL_PATH = "backend/model/best.pt"   # Load from model directory
try:
    model = YOLO(MODEL_PATH)
    model_loaded = True
    print(f"✅ Model loaded successfully from {MODEL_PATH}")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    model_loaded = False
    model = None

CONF_THRESHOLD = 0.25

# ----------------------------
# HEALTH CHECK ✅
# ----------------------------
@app.get("/health")
def health():
    return {
        "status": "healthy",
        "model_loaded": model_loaded,
        "model_path": MODEL_PATH if model_loaded else "Not loaded"
    }

# ----------------------------
# IMAGE UPLOAD DETECTION
# ----------------------------
@app.post("/detect")
async def detect_microplastics(file: UploadFile = File(...)):
    contents = await file.read()

    np_arr = np.frombuffer(contents, np.uint8)
    image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    results = model(image, conf=CONF_THRESHOLD)[0]

    detections = []
    for box in results.boxes:
        x1, y1, x2, y2 = map(int, box.xyxy[0])
        conf = float(box.conf[0])
        cls = int(box.cls[0])

        detections.append({
            "bbox": [x1, y1, x2, y2],
            "confidence": round(conf, 3),
            "class": cls
        })

    return {
        "count": len(detections),
        "detections": detections
    }

# ----------------------------
# LIVE FRAME DETECTION (for video frames)
# ----------------------------
@app.post("/detect-frame")
async def detect_frame(file: UploadFile = File(...)):
    """Process a single video frame for live detection"""
    if not model_loaded:
        return {"error": "Model not loaded", "count": 0, "detections": []}
    
    try:
        contents = await file.read()
        np_arr = np.frombuffer(contents, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        
        if frame is None:
            return {"error": "Invalid frame", "count": 0, "detections": []}
        
        results = model(frame, conf=CONF_THRESHOLD)[0]
        
        detections = []
        for box in results.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            conf = float(box.conf[0])
            cls = int(box.cls[0])
            
            detections.append({
                "bbox": [x1, y1, x2, y2],
                "confidence": round(conf, 3),
                "class": cls,
                "size_mm": round(((x2 - x1) + (y2 - y1)) / 2 * 0.1, 2)
            })
        
        return {
            "success": True,
            "count": len(detections),
            "detections": detections,
            "timestamp": str(np.datetime64('now'))
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "count": 0,
            "detections": []
        }

# ----------------------------
# LIVE WEBSOCKET DETECTION 🎥
# ----------------------------
@app.websocket("/ws/detect")
async def websocket_detect(websocket: WebSocket):
    await websocket.accept()

    while True:
        try:
            data = await websocket.receive_text()

            img_bytes = base64.b64decode(data)
            np_arr = np.frombuffer(img_bytes, np.uint8)
            frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

            results = model(frame, conf=CONF_THRESHOLD)[0]

            detections = []
            for box in results.boxes:
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                conf = float(box.conf[0])
                cls = int(box.cls[0])

                detections.append({
                    "bbox": [x1, y1, x2, y2],
                    "confidence": round(conf, 3),
                    "class": cls
                })

            await websocket.send_json({
                "count": len(detections),
                "detections": detections
            })

        except Exception as e:
            print("WebSocket error:", e)
            break
