import os
from ultralytics import YOLO
import logging

logger = logging.getLogger(__name__)

# Model path
MODEL_PATH = os.path.join(os.path.dirname(__file__), "model", "best.pt")

try:
    # Load the trained YOLOv8 model
    if os.path.exists(MODEL_PATH):
        model = YOLO(MODEL_PATH)
        logger.info(f"Model loaded successfully from {MODEL_PATH}")
    else:
        logger.warning(f"Model file not found at {MODEL_PATH}")
        logger.info("Please place your best.pt model in backend/model/ directory")
        model = None
except Exception as e:
    logger.error(f"Error loading model: {e}")
    model = None

def get_model():
    """Get the model instance"""
    if model is None:
        raise RuntimeError("Model not loaded. Please ensure best.pt exists in backend/model/")
    return model
